class Product {
  String pname, pprice, pdicription, pcatcory, pimagelocation, pId;
  int pQuantity;
  Product(
      {this.pId,
      this.pQuantity,
      this.pcatcory,
      this.pdicription,
      this.pimagelocation,
      this.pname,
      this.pprice});
}
