import 'package:flutter/cupertino.dart';

class OrderCar {
  String documentIdcar;
  int totalpricecar;
  String adresscar;
  OrderCar(
      {@required this.adresscar,
      @required this.totalpricecar,
      @required this.documentIdcar});
}
