import 'package:flutter/cupertino.dart';

const kmainColor = Color(0xffffc12f);
const kSecondryColor = Color(0xffFFE6AC);
const kUnActiveColor = Color(0xffC1BDB8);
const kcollictionProduct = 'Products';

const kpName = 'ProductName';
const kpPrice = 'ProductPrice';
const kpDiscription = 'ProductDiscripption';
const kpCatecoly = 'ProductCatcoly';
const kpImageLocation = 'ProductImageLocation';
const kJackets = 'jackets';
const kTshirts = 't-shirt';
const kShoes = 'shoes';
const ktrousers = 'trousers';
const kOrders = 'Orders';
const kOrderDetails = 'OrderDetails';
const kTotallPrice = 'TotallPrice';
const kAddress = 'Address';
const kProductQuantity = 'Quantity';
const kKeepMeLoggedIn = 'KeepMeLoggedIn';
