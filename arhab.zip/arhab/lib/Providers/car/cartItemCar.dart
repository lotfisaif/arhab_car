import 'package:arhb_car_rental/model/cars/carsItemProduct.dart';
import 'package:flutter/cupertino.dart';

class CartItemCar extends ChangeNotifier {
  List<ProductCarItem> productscar = [];

  addProductcar(ProductCarItem productcar) {
    productscar.add(productcar);
    notifyListeners();
  }

  deleteProductcar(ProductCarItem productcar) {
    productscar.remove(productcar);
    notifyListeners();
  }
}
