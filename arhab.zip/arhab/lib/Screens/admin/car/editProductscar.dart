import 'package:arhb_car_rental/Widgets/car/cutomeTextFieldcar.dart';
import 'package:arhb_car_rental/cars/contantnsCars.dart';
import 'package:arhb_car_rental/model/cars/carsItemProduct.dart';
import 'package:arhb_car_rental/services/cars/storecars.dart';
import 'package:flutter/material.dart';

class EditProductCar extends StatefulWidget {
  static String id = 'EditProductCar';

  @override
  _EditProductCarState createState() => _EditProductCarState();
}

class _EditProductCarState extends State<EditProductCar> {
  final _store = StoreCar();

  String _title;
  String _price;
  String _path;
  String _color;
  String _gearbox;
  String _fuelLiter;
  String _brand;
  String _cardoor;
  String _travellingBagSmal;
  String _travellingBagLarge;
  bool _adaptor;
  String _jeer;
  String _typeFuel;
  String _evaluation;
  String _speedKilo;

  final GlobalKey<FormState> _globalKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    ProductCarItem productscar = ModalRoute.of(context).settings.arguments;
    return Scaffold(
      body: Form(
          key: _globalKey,
          child: ListView(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _title = value;
                      },
                      hinttext: 'إسم السيارة',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _price = value;
                      },
                      hinttext: ' سعر السيارة',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _path = value;
                      },
                      hinttext: ' موقع الصورة ',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _color = value;
                      },
                      hinttext: ' اللون السيارة ',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _gearbox = value;
                      },
                      hinttext: '   عدد المقاعد',
                      icon: null),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .2,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _fuelLiter = value;
                      },
                      hinttext: ' سعة الوقود',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _brand = value;
                      },
                      hinttext: ' نوع السيارة',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _cardoor = value;
                      },
                      hinttext: '  عدد الأبواب',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _travellingBagLarge = value;
                      },
                      hinttext: '  عدد  حقائب كبيرة',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _travellingBagSmal = value;
                      },
                      hinttext: 'عدد الحقائب الصغيرة  ',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _adaptor = value;
                      },
                      hinttext: ' مكيف شغال والا معطل',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _jeer = value;
                      },
                      hinttext: ' جير تماتيكي أم يدوي',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _typeFuel = value;
                      },
                      hinttext: '  نوع الوقود',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _evaluation = value;
                      },
                      hinttext: '  التقييم',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextfieldCar(
                      onclick: (value) {
                        _speedKilo = value;
                      },
                      hinttext: '   السرعة كيلو',
                      icon: null),
                  SizedBox(
                    height: 10,
                  ),
                  RaisedButton(
                      child: Text(
                        'اضافه',
                        style: TextStyle(
                          fontFamily: 'Pacifico',
                          fontSize: 20,
                          color: Colors.white,
                        ),
                      ),
                      onPressed: () {
                        if (_globalKey.currentState.validate()) {
                          _globalKey.currentState.save();
                          _store.ditProduct({
                            ktitle: _title,
                            kprice: _price,
                            kpath: _path,
                            kcolor: _color,
                            kgearbox: _gearbox,
                            kfuelLiter: _fuelLiter,
                            kbrand: _brand,
                            kcardoor: _cardoor,
                            ktravellingBagSmal: _travellingBagSmal,
                            ktravellingBagLarge: _travellingBagLarge,
                            kadaptor: _adaptor,
                            kjeer: _jeer,
                            ktypeFuel: _typeFuel,
                            kevaluation: _evaluation,
                            kspeedKilo: _speedKilo,
                          }, productscar.pId);
                        }
                      })
                ],
              ),
            ],
          )),
    );
  }
}
