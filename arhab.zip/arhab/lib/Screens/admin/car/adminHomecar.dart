import 'package:arhb_car_rental/Screens/admin/car/addProductcar.dart';
import 'package:arhb_car_rental/Screens/admin/car/manageprodactcar.dart';
import 'package:arhb_car_rental/Screens/admin/car/orderScreencar.dart';
import 'package:arhb_car_rental/cars/contantnsCars.dart';
import 'package:flutter/material.dart';

class AdminHomeCar extends StatelessWidget {
  static String id = 'AdminHomeCar';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kmainColorcar,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            width: double.infinity,
          ),
          RaisedButton(
            onPressed: () {
              Navigator.pushNamed(context, AddProductar.id);
            },
            child: Text('Add Product'),
          ),
          RaisedButton(
            onPressed: () {
              Navigator.pushNamed(context, ManageProductCar.id);
            },
            child: Text('Edit Product'),
          ),
          RaisedButton(
            onPressed: () {
              Navigator.pushNamed(context, OrderScreenCars.id);
            },
            child: Text('View orders'),
          )
        ],
      ),
    );
  }
}
