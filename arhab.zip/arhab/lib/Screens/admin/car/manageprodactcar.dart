import 'package:arhb_car_rental/Screens/admin/car/editProductscar.dart';
import 'package:arhb_car_rental/Widgets/car/custom_menucar.dart';
import 'package:arhb_car_rental/cars/contantnsCars.dart';
import 'package:arhb_car_rental/contants.dart';
import 'package:arhb_car_rental/model/cars/carsItemProduct.dart';
import 'package:arhb_car_rental/services/cars/storecars.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ManageProductCar extends StatefulWidget {
  static String id = 'ManageProductCar';

  @override
  _ManageProductCarState createState() => _ManageProductCarState();
}

class _ManageProductCarState extends State<ManageProductCar> {
  final _store = StoreCar();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<QuerySnapshot>(
        stream: _store.loadProductCar(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            List<ProductCarItem> productscar = [];
            for (var doc in snapshot.data.documents) {
              var data = doc.data;
              productscar.add(ProductCarItem(
                pId: doc.documentID,
                title: data[ktitle],
                price: data[kpPrice],
                path: data[kpath],
                color: data[kcolor],
                gearbox: data[kgearbox],
                fuelLiter: data[kfuelLiter],
                brand: data[kbrand],
                cardoor: data[kcardoor],
                travellingBagSmal: data[ktravellingBagSmal],
                travellingBagLarge: data[ktravellingBagLarge],
                adaptor: data[kadaptor],
                jeer: data[kjeer],
                typeFuel: data[ktypeFuel],
                evaluation: data[kevaluation],
                speedKilo: data[kspeedKilo],
              ));
            }

            return GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: .8,
              ),
              itemBuilder: (context, indext) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: GestureDetector(
                  onTapUp: (details) async {
                    double dx = details.globalPosition.dx;
                    double dy = details.globalPosition.dy;
                    double dxWidth = MediaQuery.of(context).size.width - dx;
                    double dyHight = MediaQuery.of(context).size.height - dy;
                    await showMenu(
                        context: context,
                        position:
                            RelativeRect.fromLTRB(dx, dy, dxWidth, dyHight),
                        items: [
                          MyPopupMenuItem(
                            child: Text('Edit'),
                            onClick: () {
                              Navigator.pushNamed(context, EditProductCar.id,
                                  arguments: productscar[indext]);
                            },
                          ),
                          MyPopupMenuItem(
                            child: Text('Delete'),
                            onClick: () {
                              _store.deleteProductcar(productscar[indext].pId);

                              Navigator.pop(context);
                            },
                          ),
                        ]);
                  },
                  child: Stack(
                    children: <Widget>[
                      Positioned.fill(
                        child: Image(
                          fit: BoxFit.fill,
                          image: AssetImage(productscar[indext].path),
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        child: Opacity(
                          opacity: .6,
                          child: Container(
                            height: 60,
                            width: MediaQuery.of(context).size.width,
                            color: Colors.white,
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    productscar[indext].title,
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text('\$ ${productscar[indext].price}')
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              itemCount: productscar.length,
            );
          } else {
            return Center(
              child: Text('Loading...'),
            );
          }
        },
      ),
    );
  }
}
