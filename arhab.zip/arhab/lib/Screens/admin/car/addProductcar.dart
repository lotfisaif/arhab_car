import 'dart:io';

import 'package:arhb_car_rental/Widgets/car/cutomeTextFieldcar.dart';
import 'package:arhb_car_rental/model/cars/carsItemProduct.dart';
import 'package:arhb_car_rental/services/cars/storecars.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AddProductar extends StatefulWidget {
  static String id = 'AddProductar';

  @override
  _AddProductarState createState() => _AddProductarState();
}

class _AddProductarState extends State<AddProductar> {
  File _image;
  String _url;
  String _title;
  String _price;
  String _path;
  String _color;
  String _gearbox;
  String _fuelLiter;
  String _brand;
  String _cardoor;
  String _travellingBagSmal;
  String _travellingBagLarge;
  bool _adaptor;
  String _jeer;
  String _typeFuel;
  String _evaluation;
  String _speedKilo;

  final _store = StoreCar();
  final GlobalKey<FormState> _globalKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      body: Form(
        key: _globalKey,
        child: ListView(
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _title = value;
                    },
                    hinttext: 'إسم السيارة',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _price = value;
                    },
                    hinttext: ' سعر السيارة',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        CircleAvatar(
                          backgroundImage:
                              _image == null ? null : FileImage(_image),
                          radius: 80,
                        ),
                        GestureDetector(
                            onTap: pickImage, child: Icon(Icons.camera_alt))
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Builder(
                          builder: (context) => RaisedButton(
                            onPressed: () {
                              // uploadImage(context);
                            },
                            child: Text('Upload Image'),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        RaisedButton(
                          // onPressed: loadImage,
                          child: Text('Load Image'), onPressed: () {},
                        )
                      ],
                    )
                  ],
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _path = value;
                    },
                    hinttext: ' موقع الصورة ',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _color = value;
                    },
                    hinttext: ' اللون السيارة ',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _gearbox = value;
                    },
                    hinttext: '   عدد المقاعد',
                    icon: null),
                SizedBox(
                  height: MediaQuery.of(context).size.height * .2,
                ),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _fuelLiter = value;
                    },
                    hinttext: ' سعة الوقود',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _brand = value;
                    },
                    hinttext: ' نوع السيارة',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _cardoor = value;
                    },
                    hinttext: '  عدد الأبواب',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _travellingBagLarge = value;
                    },
                    hinttext: '  عدد  حقائب كبيرة',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _travellingBagSmal = value;
                    },
                    hinttext: 'عدد الحقائب الصغيرة  ',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _adaptor = value;
                    },
                    hinttext: ' مكيف شغال والا معطل',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _jeer = value;
                    },
                    hinttext: ' جير تماتيكي أم يدوي',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _typeFuel = value;
                    },
                    hinttext: '  نوع الوقود',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _evaluation = value;
                    },
                    hinttext: '  التقييم',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                CustomTextfieldCar(
                    onclick: (value) {
                      _speedKilo = value;
                    },
                    hinttext: '   السرعة كيلو',
                    icon: null),
                SizedBox(
                  height: 10,
                ),
                RaisedButton(
                    child: Text(
                      'اضافه',
                      style: TextStyle(
                        fontFamily: 'Pacifico',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                    onPressed: () {
                      if (_globalKey.currentState.validate()) {
                        _globalKey.currentState.save();
                        _store.addproductCar(ProductCarItem(
                            title: _title,
                            price: _price,
                            path: _path,
                            color: _color,
                            gearbox: _gearbox,
                            fuelLiter: _fuelLiter,
                            brand: _brand,
                            cardoor: _cardoor,
                            travellingBagSmal: _travellingBagSmal,
                            travellingBagLarge: _travellingBagLarge,
                            adaptor: _adaptor,
                            jeer: _jeer,
                            typeFuel: _typeFuel,
                            evaluation: _evaluation,
                            speedKilo: _speedKilo));
                      }
                    })
              ],
            ),
          ],
        ),
      ),
    );
  }

  void pickImage() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);

    setState(() {
      _image = image;
    });
  }

  void uploadImage(context) async {
    // try {
    //   FirebaseStorage storage =
    //       FirebaseStorage(storageBucket: 'gs://test-193e1.appspot.com');
    //   StorageReference ref = storage.ref().child(_image.path);
    //   StorageUploadTask storageUploadTask = ref.putFile(_image);
    //   StorageTaskSnapshot taskSnapshot = await storageUploadTask.onComplete;
    //   Scaffold.of(context).showSnackBar(SnackBar(
    //     content: Text('success'),
    //   ));
    //   String url = await taskSnapshot.ref.getDownloadURL();
    //   print('url $url');
    //   setState(() {
    //     _url = url;
    //   });
    // } catch (ex) {
    //   Scaffold.of(context).showSnackBar(SnackBar(
    //     content: Text(ex.message),
    //   ));
    // }
  }

  void loadImage() async {
    // var imageId = await ImageDownloader.downloadImage(_url);
    // var path = await ImageDownloader.findPath(imageId);
    // File image = File(path);
    // setState(() {
    //   _image = image;
    // });
  }
}
